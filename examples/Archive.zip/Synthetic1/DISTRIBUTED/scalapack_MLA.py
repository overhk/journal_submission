#! /usr/bin/env python3

"""
Example of invocation of this script:

mpirun -n 1 python scalapack_MLA.py -mmax 5000 -nmax 5000 -nprocmin_pernode 1 -ntask 5 -nrun 10 -jobid 0 -tla_I 0 -tla_II 0

where:
    -mmax (nmax) is the maximum number of rows (columns) in a matrix
    -nprocmin_pernode is the minimum number of MPIs per node for launching the application code
    -ntask is the number of different matrix sizes that will be tuned
    -nrun is the number of calls per task 
    -jobid is optional. You can always set it to 0.
    -tla_I is whether TLA_I is used after MLA
    -tla_II is whether TLA_II is used after MLA
"""

################################################################################
import sys
import os
sys.path.insert(0, os.path.abspath(__file__ + "/../../../../GPTune/"))

from autotune.search import *
from autotune.space import *
from autotune.problem import *
from gptune import * # import all

import numpy as np
import argparse
import pickle
from random import *
import time
import math


################################################################################

''' The objective function required by GPTune. '''
# should always use this name for user-defined objective function
def objectives(point):


    m = point['m']
    mb = point['mb']
    nb = point['nb']

    return [(nb+35)*m/(mb-0.25)]


def main():

    global JOBID

    # Parse command line arguments
    args = parse_args()
    nParallel = args.nParallel
    whichLiar = args.whichLiar

    nrun = args.nrun
    JOBID = args.jobid
    tuning_metadata=None

#    (machine, processor, nodes, cores) = GetMachineConfiguration(meta_dict = tuning_metadata)
    (machine, processor, nodes, cores) = GetMachineConfiguration()    
    print ("machine: " + machine + " processor: " + processor + " num_nodes: " + str(nodes) + " num_cores: " + str(cores))


    m = Integer(1,50, transform="normalize", name="m")

    mb = Integer(1, 96, transform="normalize", name="mb")
    nb = Integer(1, 96, transform="normalize", name="nb")

    r = Real(float("-Inf"), float("Inf"), name="r")

    IS = Space([m])
    PS = Space([mb, nb])
    OS = Space([r])
    
    constraints = {}
    constants={}

    print(IS, PS, OS, constraints)

    problem = TuningProblem(IS, PS, OS, objectives, constraints, None, constants=constants)
    #historydb = HistoryDB(meta_dict=tuning_metadata)
    computer = Computer(nodes=nodes, cores=cores, hosts=None)

    """ Set and validate options """
    options = Options()
    options['model_processes'] = 1
    # options['model_threads'] = 1
    options['model_restarts'] = 1
    # options['search_multitask_processes'] = 1
    # options['model_restart_processes'] = 1
    # options['model_restart_threads'] = 1
    options['distributed_memory_parallelism'] = False
    options['shared_memory_parallelism'] = False
    # options['mpi_comm'] = None
    options['model_class'] = 'Model_GPy_LCM'
    options['sample_class']='SampleOpenTURNS'
    options['verbose'] = False
    if whichLiar==9:
        options['BO_objective_evaluation_parallelism'] = False
    else:
        options['BO_objective_evaluation_parallelism'] = True
    options['sample_random_seed'] = JOBID 
    options.validate(computer=computer)

    seed(JOBID)
    giventask = [[1]]
    ntask=len(giventask)

    data = Data(problem)

    gt = GPTune(problem, computer=computer, data=data, options=options)

    """ Building MLA with the given list of tasks """
    NI = len(giventask)
    NS = nrun
    (data, model, stats) = gt.MLA(NS=NS, Tgiven=giventask, NI=NI, NS1=1,numInParallel=nParallel, lieType=whichLiar)
    print("stats: ", stats)

    """ Print all input and parameter samples """
    for tid in range(NI):
            print("tid: %d" % (tid))
            print("    m:%d " % (data.I[tid][0]))
            print("    Ps ", data.P[tid])
            print("    Os ", data.O[tid].tolist())
            print('    Popt ', data.P[tid][np.argmin(data.O[tid])], 'Oopt ', min(data.O[tid])[0], 'nth ', np.argmin(data.O[tid]))


def parse_args():

    parser = argparse.ArgumentParser()

    # Problem related arguments
    parser.add_argument('-nrun', type=int, help='Number of runs per task')
    parser.add_argument('-jobid', type=int, default=-1, help='ID of the batch job')
    parser.add_argument('-nParallel', type=int, default=1, help='Number of parallel objective function evaluations')
    parser.add_argument('-whichLiar', type=int)

    args = parser.parse_args()

    return args

if __name__ == "__main__":
    main()
