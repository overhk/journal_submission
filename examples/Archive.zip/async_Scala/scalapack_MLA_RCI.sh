#!/bin/bash
start=`date +%s`

# Get nrun and nprocmin_pernode from command line
while getopts "a:b:c:d:e:f:g:h:" opt
do
   case $opt in
      a ) nrun=$OPTARG ;; # NS
      b ) nprocmin_pernode=$OPTARG ;; # mpi count per node
      c ) mmax=$OPTARG ;; # max number of rows
      d ) nmax=$OPTARG ;; # max number of columns
      e ) ntask=$OPTARG ;; # tasks
      f ) NS1=$OPTARG ;; # NS1
      g ) NParallel=$OPTARG ;; # NParallel
      h ) liarStrat=$OPTARG ;; # Liar strategy
      ? ) echo "unrecognized bash option $opt" ;; # Print helpFunction in case parameter is non-existent
   esac
done


###############
cd ../../

export PYTHONPATH=$PYTHONPATH:$PWD/autotune/
export PYTHONPATH=$PYTHONPATH:$PWD/scikit-optimize/
export PYTHONPATH=$PYTHONPATH:$PWD/mpi4py/
export PYTHONPATH=$PYTHONPATH:$PWD/GPTune/
export PYTHONPATH=$PYTHONPATH:$PWD/GPy/
export PATH=$PATH:$PWD/jq-1.6
export PYTHONPATH=$PYTHONPATH:$PWD/openturns/build/share/gdb/auto-load/$PWD
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$PWD/pagmo2/build/
export PYTHONWARNINGS=ignore

cd -

# name of your machine, processor model, number of compute nodes, number of cores per compute node, which are defined in .gptune/meta.json
declare -a machine_info=($(python -c "from gptune import *;
(machine, processor, nodes, cores)=list(GetMachineConfiguration());
print(machine, processor, nodes, cores)"))
machine=${machine_info[0]}
processor=${machine_info[1]}
nodes=${machine_info[2]}
cores=${machine_info[3]}


obj=r                   # name of the objective defined in the python file

niter=1                 # number of repeating each application run
bunit=8                 # mb,nb is integer multiple of bunit

database="gptune.db/PDGEQRF.json"  # the phrase PDGEQRF should match the application name defined in .gptune/meta.jason


python scala_async.py -nrun $nrun -mmax $mmax -nmax $nmax -ntask $ntask -bunit $bunit \
                      -nprocmin_pernode $nprocmin_pernode -NS1 $NS1 -nParallel $NParallel \
                      -cores $cores -machine $machine -niter 1 -nodes $nodes -whichLiar $liarStrat
