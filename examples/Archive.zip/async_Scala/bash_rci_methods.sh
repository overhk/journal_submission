#!/bin/bash




writeResult() {
    local idx=$1
    jobid=$idx
    local machine=$2
    local tp=$3
    local database="gptune.db/${tp}.json"
    local bunit=$4
    local cores=$5
    local niter=$6
    

    # echo "Bash idx: $idx"
    # echo "Bash machine: $machine"
    # echo "Bash database: $database"
    # echo "Bash bunut: $bunit"

    declare -a input_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].task_parameter' $database | jq -r '.[]'))
    declare -a tuning_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].tuning_parameter' $database | jq -r '.[]'))


     # get the task input parameters, the parameters should follow the sequence of definition in the python file
    # rows and columns
    m=${input_para[0]}
    n=${input_para[1]}

    # get the tuning parameters, the parameters should follow the sequence of definition in the python file
    
    # row and column block size
    mb=$((${tuning_para[0]} * $bunit))
    nb=$((${tuning_para[1]} * $bunit))
    
    # max number of cores avaliable
    lg2npernode=${tuning_para[2]}
    p=${tuning_para[3]}


    # minimum number of MPIs per node for launching the application code
    npernode=$((2**$lg2npernode))

    OMP_NUM_THREADS=$(($cores / $npernode))


    nproc=$(($nodes*$npernode))
    q=$(($nproc / $p))

    
    # echo  "./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $jobid -niter $niter -mode 'out' -m $m -n $n -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS -nproc $nproc -p $p -q $q -npernode $npernode | tee ${idx}_result.out"
    obj="r"
                                        
    # # call the python wrapper to read results from the output file and print it out
    python ./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $jobid -niter $niter -mode 'out' -m $m -n $n \
                                                       -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS \
                                                       -nproc $nproc -p $p -q $q -npernode $npernode | tee ${idx}_result.out
    
    result=$(grep 'PDGEQRF time:' ${idx}_result.out | grep -Eo '[+-]?[0-9]+([.][0-9]+)?')
    jq --arg v0 $obj --argjson v1 $idx --argjson v2 $result '.func_eval[$v1].evaluation_result[$v0]=$v2' $database > tmp.json && mv tmp.json $database
}

lieToDatabase() {
    local tp=$1
    local database="gptune.db/${tp}.json"
    local idx=$2
    local result=$3
    obj="r"

    jq --arg v0 $obj --argjson v1 $idx --argjson v2 $result '.func_eval[$v1].evaluation_result[$v0]=$v2' $database > tmp.json && mv tmp.json $database
}

findNextNullParam() {
    local tp=$1
    local database="gptune.db/${tp}.json"
    local obj=$2
    local idx=$(jq -r --arg v0 $obj '.func_eval | map(.evaluation_result[$v0] == null) | index(true) ' $database)
    echo $idx
}

setBigValue() {
    local tp=$1
    local database="gptune.db/${tp}.json"
    local obj=$2
    local idx=$3
    local bigval=1e30

    jq --arg v0 $obj --argjson v1 $idx --argjson v2 $bigval '.func_eval[$v1].evaluation_result[$v0]=$v2' $database > tmp.json && mv tmp.json $database
}

evaluateObjective() {
    local idx=$1
    local machine=$2
    local nodes=$3
    local tp=$4
    local database="gptune.db/${tp}.json"
    

    declare -a tuning_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].tuning_parameter' $database | jq -r '.[]'))
    lg2npernode=${tuning_para[2]}
    npernode=$((2**$lg2npernode))
    nproc=$(($nodes*$npernode))


    jobid=$idx
    BINDIR=./scalapack-driver/bin/$machine/
    RUNDIR=./scalapack-driver/exp/$machine/GPTune/$jobid/
    echo "timeout 60 srun -N 1 -n $nproc -c $((128 /$nproc )) $BINDIR/pdqrdriver $RUNDIR"
    timeout 60 srun -N 1 -n $nproc -c $((128 /$nproc )) --cpu_bind=cores $BINDIR/pdqrdriver $RUNDIR && echo "Completed" || echo "Error"
}

setupQRIn(){

    local idx=$1
    local tp=$2
    local database="gptune.db/${tp}.json"
    local bunit=$3
    local cores=$4
    local machine=$5
    local niter=$6
    local nodes=$7

    echo "local $nodes"
    declare -a input_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].task_parameter' $database | jq -r '.[]'))
    declare -a tuning_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].tuning_parameter' $database | jq -r '.[]'))

    echo "Input para"
    for item in "${input_para[@]}"
    do
        echo "$item"
    done

    echo "Tuning"
        for item in "${tuning_para[@]}"
    do
        echo "$item"
    done


    # get the task input parameters, the parameters should follow the sequence of definition in the python file
    # rows and columns
    m=${input_para[0]}
    n=${input_para[1]}

    # get the tuning parameters, the parameters should follow the sequence of definition in the python file
    
    # row and column block size
    mb=$((${tuning_para[0]}*$bunit))
    nb=$((${tuning_para[1]}*$bunit))
    
    # max number of cores avaliable
    lg2npernode=${tuning_para[2]}
    p=${tuning_para[3]}


    # # call the application
    #     # minimum number of MPIs per node for launching the application code
    npernode=$((2**$lg2npernode))


    export OMP_NUM_THREADS=$(($cores / $npernode))


    nproc=$(($nodes*$npernode))
    q=$(($nproc / $p))

    # sets the jobid to idx so that each idx eval has its own directory
    jobid=$idx


    BINDIR=./scalapack-driver/bin/$machine/
    RUNDIR=./scalapack-driver/exp/$machine/GPTune/$jobid/

    echo $BINDIR
    echo $RUNDIR
    # # call the python wrapper to dump parameters to an input file
    # python 

    # echo "./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $jobid -niter $niter -mode 'in' \
    #  -m $m -n $n -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS -nproc $nproc -p $p -q \
    #  $q -npernode $npernode"
    python ./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $jobid -niter $niter -mode 'in' \
     -m $m -n $n -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS -nproc $nproc -p $p -q \
     $q -npernode $npernode



}

# Determine which method to call based on the provided string
method="$1"

if [[ $method == "writeResult" ]]; then
    writeResult "$2" "$3" "$4" "$5" "$6" "$7"
elif [[ $method == "findNextNullParam" ]]; then
    findNextNullParam "$2" "$3"
elif [[ $method == "setBigValue" ]]; then
    setBigValue "$2" "$3" "$4"
elif [[ $method == "evaluateObjective" ]]; then
    evaluateObjective "$2" "$3" "$4" "$5"
elif [[ $method == "setupQRIn" ]]; then
    setupQRIn "$2" "$3" "$4" $5 $6 $7 $8
elif [[ $method == "lieToDatabase" ]]; then
    lieToDatabase "$2" "$3" "$4"
else
    echo "Invalid method specified."
    exit 1
fi
