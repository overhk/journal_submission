import sys
import os


from autotune.search import *
from autotune.space import *
from autotune.problem import *
from gptune import * 
#from callhybrid import GPTuneHybrid

import numpy as np
from random import *
import time
import math
import subprocess
# from utilities import *

import threading
import time
import csv

sys.path.insert(0, os.path.abspath(__file__ + "/../../../GPTune/"))
sys.path.insert(0, os.path.abspath(__file__ + "/../scalapack-driver/spt/"))



import argparse
import pickle
from random import *
# from callopentuner import OpenTuner
# from callhpbandster import HpBandSter
import time
import math


####################

activeThreads = 0
resultFiles = []

completion_times = {}
lock = threading.Lock()
database = "gptune.db/PDGEQRF.json"
start_time = time.time()


def thread_function(idx, machine,nodes):
    global activeThreads
    global resultFiles
    global database
    global start_time
    cd = os.getcwd()
    
    print("Hi! I am a thread executing idx ", idx)
   
    process = subprocess.run(["bash", "bash_rci_methods.sh", "evaluateObjective", str(idx), str(machine), str(nodes),str("PDGEQRF")], capture_output=True, text=True)
    
    if "Completed" in process.stdout.strip() and "Error" not in process.stdout.strip():
        print(f"Idx {idx} completed successfully.")
        with lock:
                resultFiles.append(f"{idx}")
                completion_times[str(idx)] = time.time() - start_time
    elif "Error" in process.stdout.strip() :
        print(f"Idx {idx} failed; check {idx}.output for the specific error; if blank, it is a timeout error")
        print(f"thread {idx} stdout: {process.stdout}")
        print(f"thread {idx} stderr: {process.stderr}")
        resultFiles.append(f"failed-{idx}")


    else:
        print("Unknown behavior")

    with lock:
        activeThreads -= 1   



def read_csv_line(file_name, line_number):
    with open(file_name, 'r') as csv_file:
        csv_reader = csv.reader(csv_file)
        lines = list(csv_reader)

        if line_number < 0:
            print(f"Invalid line number. The file has {len(lines)} lines.")
            return None

        line_data = lines[line_number]

    return line_data

def generate_param_suggestions(mmax, nmax, ntask, bunit, nprocmin_pernode, nrun, tla, JOBID, optimization, NS1, nParallel, liar, cores, machine,\
                                niter, nodes, liarStrat, first=False):
    global database

    
    result = subprocess.run(["python", "scalapack_MLA_RCI.py", "-mmax", str(mmax), "-nmax", str(nmax), "-ntask", str(ntask), 
                             "-bunit", str(bunit), "-nprocmin_pernode", str(nprocmin_pernode), "-nrun", str(nrun), "-tla",
                                str(tla), "-jobid", str(JOBID), "-optimization", str(optimization), "-NS1", str(NS1), "-nParallel",
                                 str(nParallel), "-liar", str(liar), "-whichLiar", str(liarStrat)], capture_output=True, text=True)

    print(result.stdout)
    print(result.stderr)    
    count = 0
    ids = []

    while True:
        result = subprocess.run(["bash", "bash_rci_methods.sh", "findNextNullParam", "PDGEQRF", "r"], capture_output=True, text=True)
        idx = result.stdout.strip()
        print(result.stdout)
        print(result.stderr)    
        print("idx: ", idx)
        if idx == "null":
            break

        ids.append(int(idx))

        result = subprocess.run(["bash", "bash_rci_methods.sh", "setupQRIn", str(idx),  "PDGEQRF",str(bunit), str(cores), \
                                str(machine), str(niter), str(nodes)], capture_output=True, text=True)

  
        if first:
            subprocess.run(["bash", "bash_rci_methods.sh", "lieToDatabase", "PDGEQRF", str(idx),str("1e30")], capture_output=True, text=True)
            
        else:
            param_prediction = read_csv_line("test.csv", int(idx))
            pred = float(param_prediction[1])
            print("Param prediction: ", pred)
            subprocess.run(["bash", "bash_rci_methods.sh", "lieToDatabase", "PDGEQRF", str(idx),str(pred)], capture_output=True, text=True)
        count += 1
    return ids, count

def main():
    global activeThreads
    global resultFiles
    global completion_times

    # Parse command line arguments   
    print("Top of main")
    args = parse_args()
    mmax = args.mmax
    nmax = args.nmax
    ntask = args.ntask
    bunit = args.bunit
    nprocmin_pernode = args.nprocmin_pernode
    nrun = args.nrun
    tla = args.tla
    JOBID = args.jobid
    TUNER_NAME = args.optimization
    
   
    nParallel = args.nParallel
    NS1 = args.NS1
    cores = args.cores
    machine = args.machine
    niter = args.niter
    nodes = args.nodes
    liarStrat = args.whichLiar
    
    

    
   

    print("GPTune setting up NS1 parms")
    ids, count = generate_param_suggestions(mmax, nmax, ntask, bunit, nprocmin_pernode, nrun, tla, JOBID, TUNER_NAME,NS1,nParallel, 0,cores, machine, niter, nodes, liarStrat, first=True)
    print("GPTune completed NS1 parm setup")

    index = 0
    print("Starting NS1")
    while (index < NS1):
        for _ in range(nParallel):
            with lock:
                if index >= NS1:
                    break
                threading.Thread(target=thread_function, args=(ids[index], machine,nodes,)).start()
                activeThreads +=1
                index += 1 
        
        # let NS values run
        while(True):
    
            with lock:
                if activeThreads == 0:
                    break
            time.sleep(1)
    print("NS1 runs completed")
    temp = len(resultFiles)
    print("result files: ", resultFiles)

    print("Writing Results from NS1")
    for i in range(temp):
        
        if len(resultFiles) == 0:
            break
        else:

            if "failed" in resultFiles[0]:
                local_idx = str(resultFiles[0]).split("-")[1]
                subprocess.run(["bash", "bash_rci_methods.sh", "lieToDatabase", "PDGEQRF", str(local_idx),str("1e30")], capture_output=True, text=True)
                with open(f'{local_idx}_result.out', 'w') as file:
                    # Write a new line to the file
                    file.write(f"Param Failed: {-1} \n")
                    file.write(f"Param Failed: {-1} \n")
                    file.write(f"Time since start: {-1} \n")
                
            else:
                result = subprocess.run(["bash", "bash_rci_methods.sh", "writeResult", str(resultFiles[0]),str(machine),"PDGEQRF",\
                                        str(bunit), str(cores), str(niter)], capture_output=True, text=True)
                

                with open(f'{resultFiles[0]}_result.out', 'a') as file:
                    # Write a new line to the file
                    file.write(f"Time since start: {completion_times[resultFiles[0]]} \n")
            resultFiles =  resultFiles[1:]


    print("Wrote results from NS1")

    print("NS1 done")

    # handle edge case where NS1 > NS
    if index >= nrun:
        runtime = time.time() - start_time
        print(f"GPTune done with a runtime of: {runtime}")
        print("Results")
        print("___________________________")
        result = subprocess.run(["python", "scalapack_MLA_RCI.py", "-mmax", str(mmax), "-nmax", str(nmax), "-ntask", str(ntask), 
                                "-bunit", str(bunit), "-nprocmin_pernode", str(nprocmin_pernode), "-nrun", str(nrun), "-tla",
                                    str(tla), "-jobid", str(JOBID), "-optimization", str(TUNER_NAME), "-NS1", str(NS1), "-nParallel",
                                    str(nParallel), "-liar", str(0), "-whichLiar", str(liarStrat)], capture_output=True, text=True)
        
        print(result.stdout)
        with open('results.csv', 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Total Runtime", str(runtime)])  # Write header row
        
        exit(1)

    # call GPTune and update the database with nParallel suggestions based on lies
    print(f"GPTune generating {nParallel} lies")
    temp, count = generate_param_suggestions(mmax, nmax, ntask, bunit, nprocmin_pernode, nrun, tla, JOBID, TUNER_NAME,NS1,nParallel, 1 ,cores, machine, niter, nodes, liarStrat)
    ids.extend(temp)
    print(f"GPTune done generating {nParallel} lies")
    
    # kick off nParallel threads based on the lies
    for i in range(nParallel):
        threading.Thread(target=thread_function, args=(ids[index], machine,nodes,)).start()
        with lock:
            activeThreads +=1
            index += 1

    
    # this loop will continously make sure there are nParallel threads until we have executed NS times
    while True:
        with lock:
            
            # if we have no more threads going and all the results have been written to the database, break
            if activeThreads == 0 and index >= nrun and len(resultFiles) == 0:
                break

            
            if activeThreads < nParallel:
                # write a result to the database
                if len(resultFiles) != 0:
                    
                    if "failed" in resultFiles[0]:
                        local_idx = str(resultFiles[0]).split("-")[1]
                        subprocess.run(["bash", "bash_rci_methods.sh", "lieToDatabase", "PDGEQRF", str(local_idx),str("1e30")], capture_output=True, text=True)
                        with open(f'{local_idx}_result.out', 'w') as file:
                            # Write a new line to the file
                            file.write(f"Param Failed: {-1} \n")
                            file.write(f"Param Failed: {-1} \n")
                            file.write(f"Time since start: {-1} \n")
                        
                    else:
                        result = subprocess.run(["bash", "bash_rci_methods.sh", "writeResult", str(resultFiles[0]),str(machine),"PDGEQRF",\
                                                str(bunit), str(cores), str(niter)], capture_output=True, text=True)
                

                        with open(f'{resultFiles[0]}_result.out', 'a') as file:
                            # Write a new line to the file
                            file.write(f"Time since start: {completion_times[resultFiles[0]]} \n")
                    
                    resultFiles =  resultFiles[1:]

                # if we have not run NS evaluations, spawn a new thread with the next suggestion
                if index < nrun:
                    # call GPTune and add one new suggestion to the database
                    print("Generating new suggestion based on data")
                    temp, count = generate_param_suggestions(mmax, nmax, ntask, bunit, nprocmin_pernode, nrun, tla, JOBID, TUNER_NAME,NS1,1, 1 ,cores, machine, niter, nodes , liarStrat)
                    ids.extend(temp)
                    print("GPT done generating")
                    threading.Thread(target=thread_function, args=(ids[index], machine,nodes,)).start()
                    activeThreads += 1
                    index += 1
                
        
    
    
    runtime = time.time() - start_time
    print(f"GPTune done with a runtime of: {runtime}")
    print("Results")
    print("___________________________")
    result = subprocess.run(["python", "scalapack_MLA_RCI.py", "-mmax", str(mmax), "-nmax", str(nmax), "-ntask", str(ntask), 
                             "-bunit", str(bunit), "-nprocmin_pernode", str(nprocmin_pernode), "-nrun", str(nrun), "-tla",
                                str(tla), "-jobid", str(JOBID), "-optimization", str(TUNER_NAME), "-NS1", str(NS1), "-nParallel",
                                 str(nParallel), "-liar", str(0),"-whichLiar", str(liarStrat)], capture_output=True, text=True)

    print(result.stdout)
    with open('results.csv', 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["Total Runtime", str(runtime)])  # Write header row

def parse_args():

    parser = argparse.ArgumentParser()

    # Problem related arguments
    parser.add_argument('-mmax', type=int, default=-1, help='Number of rows')
    parser.add_argument('-nmax', type=int, default=-1, help='Number of columns')    
    parser.add_argument('-bunit', type=int, default=8, help='mb and nb are integer multiples of bunit')
    # Machine related arguments
    parser.add_argument('-nodes', type=int, default=1,help='Number of machine nodes')
    parser.add_argument('-cores', type=int, default=1,help='Number of cores per machine node')
    parser.add_argument('-nprocmin_pernode', type=int, default=1,help='Minimum number of MPIs per machine node for the application code')
    parser.add_argument('-machine', type=str,help='Name of the computer (not hostname)')
    # Algorithm related arguments    
    parser.add_argument('-optimization', type=str,default='GPTune', help='Optimization algorithm (opentuner, hpbandster, GPTune)')
    parser.add_argument('-tla', type=int, default=0, help='Whether perform TLA after MLA when optimization is GPTune')    
    parser.add_argument('-ntask', type=int, default=-1, help='Number of tasks')
    parser.add_argument('-nrun', type=int, help='Number of runs per task')
    parser.add_argument('-niter', type=int, help='Number of iterations per configuration')
    
    

    # Experiment related arguments
    parser.add_argument('-jobid', type=int, default=-1, help='ID of the batch job')
    parser.add_argument('-NS1', type=int, default=1, help='Number of inital configs to be randomly evaluated')
    parser.add_argument('-nParallel', type=int, default=1, help='Number of parallel objective function evaluations')
    parser.add_argument('-whichLiar', type=int)



    args = parser.parse_args()

    return args


if __name__ == "__main__":
    main()
