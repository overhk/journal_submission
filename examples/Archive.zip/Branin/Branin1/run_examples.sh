#!/bin/bash



NS=80

cd ../../../
. run_env.sh
cd -

rm -rf gptune.db/*.json # do not load any database 
tp=PDGEQRF
app_json=$(echo "{\"tuning_problem_name\":\"$tp\"")
mkdir -p .gptune
echo "$app_json$machine_json$software_json$loadable_machine_json$loadable_software_json}" | jq '.' > .gptune/meta.json


input_parallel=( 8 )
#input_lies=( 0 1 2 3 4 5 6 9 )
input_lies=( 1 7 8 )
attempts=5



for ((i=1; i<=$attempts; i++)); do
	mkdir -p attempt_$i

for np in "${input_parallel[@]}"
do
	for liar in "${input_lies[@]}"
	do
		
	sh clean.sh 

	python ./scalapack_MLA.py -nrun $NS -jobid $i -nParallel $np -whichLiar $liar  | tee log.test
	databas=dynamic_test_Async_${np}_Node_NS_${NS}_NS1_1_Metric_${liar}
	mkdir -p attempt_${i}/$databas
	mv gptune.db/PDGEQRF.json attempt_${i}/$databas/
	mv predictions.csv attempt_${i}/$databas/
  	mv test.csv attempt_${i}/$databas/
  	mv log.test attempt_${i}/$databas/

	done
done
done
