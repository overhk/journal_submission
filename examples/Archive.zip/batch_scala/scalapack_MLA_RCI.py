#! /usr/bin/env python3
# GPTune Copyright (c) 2019, The Regents of the University of California,
# through Lawrence Berkeley National Laboratory (subject to receipt of any
# required approvals from the U.S.Dept. of Energy) and the University of
# California, Berkeley.  All rights reserved.
#
# If you have questions about your rights to use or distribute this software,
# please contact Berkeley Lab's Intellectual Property Office at IPO@lbl.gov.
#
# NOTICE. This Software was developed under funding from the U.S. Department
# of Energy and the U.S. Government consequently retains certain rights.
# As such, the U.S. Government has been granted for itself and others acting
# on its behalf a paid-up, nonexclusive, irrevocable, worldwide license in
# the Software to reproduce, distribute copies to the public, prepare
# derivative works, and perform publicly and display publicly, and to permit
# other to do so.
#
################################################################################

"""
Example of invocation of this script:

python scalapack_MLA_RCI.py -mmax 5000 -nmax 5000 -nprocmin_pernode 1 -ntask 5 -nrun 10 -jobid 0 -bunit 8

where:
    -mmax (nmax) is the maximum number of rows (columns) in a matrix
    -nprocmin_pernode is the minimum number of MPIs per node for launching the application code
    -ntask is the number of different matrix sizes that will be tuned
    -nrun is the number of calls per task 
    -jobid is optional. You can always set it to 0.
    -tla is whether TLA is used after MLA
"""

################################################################################
import sys
import os
sys.path.insert(0, os.path.abspath(__file__ + "/../../../GPTune/"))
sys.path.insert(0, os.path.abspath(__file__ + "/../scalapack-driver/spt/"))

from autotune.search import *
from autotune.space import *
from autotune.problem import *
from gptune import * # import all

import numpy as np
import argparse
import pickle
from random import *
import time
import math


################################################################################

''' The objective function required by GPTune. '''
# should always use this name for user-defined objective function
def objectives(point):                          
	print('objective is not needed when options["RCI_mode"]=True')

def cst1(mb,p,m,bunit):
    return mb*bunit * p <= m
def cst2(nb,lg2npernode,n,p,nodes,bunit):
    return nb * bunit * nodes * 2**lg2npernode <= n * p
def cst3(lg2npernode,p,nodes):
    return nodes * 2**lg2npernode >= p

def main():



    # Parse command line arguments
    args = parse_args()
    mmax = args.mmax
    nmax = args.nmax
    ntask = args.ntask
    bunit = args.bunit
    nprocmin_pernode = args.nprocmin_pernode
    nrun = args.nrun
    TUNER_NAME = args.optimization
    NS1 = args.NS1
    nParallel = args.nParallel
    liar = args.liar
    whichLiar = args.whichLiar

 

    
    (machine, processor, nodes, cores) = GetMachineConfiguration()


    os.environ['MACHINE_NAME'] = machine
    os.environ['TUNER_NAME'] = TUNER_NAME
    os.system("mkdir -p scalapack-driver/bin/%s;" %(machine))
    DRIVERFOUND=False
    INSTALLDIR=os.getenv('GPTUNE_INSTALL_PATH')
    DRIVER = os.path.abspath(__file__ + "/../../../build/pdqrdriver")
    if(os.path.exists(DRIVER)):
        DRIVERFOUND=True
    elif(INSTALLDIR is not None):
        DRIVER = INSTALLDIR+"/gptune/pdqrdriver"
        if(os.path.exists(DRIVER)):
            DRIVERFOUND=True
    else:
        for p in sys.path:
            if("gptune" in p):
                DRIVER=p+"/pdqrdriver"
                if(os.path.exists(DRIVER)):
                    DRIVERFOUND=True
                    break
    
    if(DRIVERFOUND == True):
        os.system("cp %s scalapack-driver/bin/%s/.;" %(DRIVER,machine))
    else:
        raise Exception(f"pdqrdriver cannot be located. Try to set env variable GPTUNE_INSTALL_PATH correctly.")


    nprocmax = nodes*cores

    mmin=128
    nmin=128

    print("python nprocmax: ", nprocmax)
    m = Integer(mmin, mmax, transform="normalize", name="m")
    n = Integer(nmin, nmax, transform="normalize", name="n")
    mb = Integer(1, 16, transform="normalize", name="mb")
    nb = Integer(1, 16, transform="normalize", name="nb")
    lg2npernode     = Integer     (int(math.log2(nprocmin_pernode)), int(math.log2(cores)), transform="normalize", name="lg2npernode")
    p = Integer(1, nprocmax, transform="normalize", name="p")
    r = Real(float("-Inf"), float("Inf"), name="r")

    IS = Space([m, n])
    PS = Space([mb, nb, lg2npernode, p])
    OS = Space([r])
    
    constraints = {"cst1": cst1, "cst2": cst2, "cst3": cst3}
    constants={"nodes":nodes,"cores":cores,"bunit":bunit}
    # print(IS, PS, OS, constraints)

    problem = TuningProblem(IS, PS, OS, objectives, constraints, None, constants=constants)
    computer = Computer(nodes=nodes, cores=cores, hosts=None)

    """ Set and validate options """
    options = Options()
    options['model_processes'] = 1
    # options['model_threads'] = 1
    options['model_restarts'] = 1
    # options['search_multitask_processes'] = 1
    # options['model_restart_processes'] = 1
    # options['model_restart_threads'] = 1
    options['distributed_memory_parallelism'] = False
    options['shared_memory_parallelism'] = False
    options['search_ei_alpha']=1
    
    options['BO_objective_evaluation_parallelism'] = True
    # options['mpi_comm'] = None
    options['model_class'] = 'Model_LCM'
    options['verbose'] = False
    options['RCI_mode'] = True

    options['sample_random_seed'] = 1
    options.validate(computer=computer)

   
    # setting the size of the matrix
    if ntask == 1:
        giventask = [[mmax,nmax]]
    else:
        giventask = [[randint(mmin,mmax),randint(nmin,nmax)] for i in range(ntask)]
    
    # this is the size of the matrix
 
    ntask=len(giventask)
    

    data = Data(problem)
    if(TUNER_NAME=='GPTune'):

        gt = GPTune(problem, computer=computer, data=data, options=options, driverabspath=os.path.abspath(__file__))
        """ Building MLA with the given list of tasks """
        NI = len(giventask)
        NS = nrun

        
        (data, model, stats) = gt.MLA(NS=NS, Tgiven=giventask, NI=NI, NS1=NS1,numInParallel=nParallel, lieType=whichLiar)
       
        
        
    import csv
    for tid in range(NI):
        print("Tid: %d" % (tid))
        print("___________________________________")
        # print("Is:%s " % (data.I[tid][0]))

        Ps = data.P[tid]
        Os = data.O[tid].tolist()
        target_idx = 0
        for P, O in zip(Ps, Os):
            print("Param: ", P ,end = '\t\t' )
            print("Result: ", O)
        print("___________________________________________")
        print('Popt ', data.P[tid][np.argmin(data.O[tid])], 'Oopt ', min(data.O[tid])[0], 'nth ', np.argmin(data.O[tid]))
        
        
        
        with open('results.csv', 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Param", "Runtime", "Time since start"])  # Write header row

            for tid in range(NI):
                Ps = data.P[tid]
                Os = data.O[tid].tolist()

                for P, O in zip(Ps, Os):
                    file_path = f"{target_idx}_result.out"  # Replace with the actual file path
                    target_idx += 1
                    with open(file_path, "r") as file:
                        lines = file.readlines()

                        if len(lines) >= 3:
                            third_line = lines[2].strip()
                            if third_line.startswith("Time since start:"):
                                number = third_line.split(":")[1].strip()
                                print("Number:", number)
                            else:
                                print("Invalid format in the third line.")
                        else:
                            print("File does not have enough lines.")
                        
                    writer.writerow([P, O, number])


def parse_args():

    parser = argparse.ArgumentParser()

    # Problem related arguments
    parser.add_argument('-mmax', type=int, default=-1, help='Number of rows')
    parser.add_argument('-nmax', type=int, default=-1, help='Number of columns')    
    parser.add_argument('-bunit', type=int, default=8, help='mb and nb are integer multiples of bunit')
    # Machine related arguments
    parser.add_argument('-nodes', type=int, default=1,help='Number of machine nodes')
    parser.add_argument('-cores', type=int, default=1,help='Number of cores per machine node')
    parser.add_argument('-nprocmin_pernode', type=int, default=1,help='Minimum number of MPIs per machine node for the application code')
    parser.add_argument('-machine', type=str,help='Name of the computer (not hostname)')
    # Algorithm related arguments    
    parser.add_argument('-optimization', type=str,default='GPTune', help='Optimization algorithm (opentuner, hpbandster, GPTune)')
    parser.add_argument('-tla', type=int, default=0, help='Whether perform TLA after MLA when optimization is GPTune')    
    parser.add_argument('-ntask', type=int, default=-1, help='Number of tasks')
    parser.add_argument('-nrun', type=int, help='Number of configs to be evaluated')
    
    # Experiment related arguments
    # 0 means interactive execution (not batch)
    parser.add_argument('-jobid', type=int, default=-1, help='ID of the batch job')

    
    parser.add_argument('-NS1', type=int, default=1, help='Number of inital configs to be randomly evaluated')
    parser.add_argument('-nParallel', type=int, default=1, help='Number of parallel objective function evaluations')
    parser.add_argument('-liar', type=int, default=0, help='Whether to use the liar strategy or not')
    parser.add_argument('-whichLiar', type=int)
    args = parser.parse_args()

    return args


if __name__ == "__main__":
    main()
