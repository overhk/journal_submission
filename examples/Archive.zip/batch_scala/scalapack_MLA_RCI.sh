#!/bin/bash
start=`date +%s`

# Get nrun and nprocmin_pernode from command line
while getopts "a:b:c:d:e:f:g:h:" opt
do
   case $opt in
      a ) nrun=$OPTARG ;; # NS
      b ) nprocmin_pernode=$OPTARG ;; # mpi count per node
      c ) mmax=$OPTARG ;; # max number of rows
      d ) nmax=$OPTARG ;; # max number of columns
      e ) ntask=$OPTARG ;; # tasks
      f ) NS1=$OPTARG ;; # NS1
      g ) NParallel=$OPTARG ;; # NParallel
      h ) liarStrat=$OPTARG ;; # Liar strategy
      ? ) echo "unrecognized bash option $opt" ;; # Print helpFunction in case parameter is non-existent
   esac
done


###############
cd ../../

export PYTHONPATH=$PYTHONPATH:$PWD/autotune/
export PYTHONPATH=$PYTHONPATH:$PWD/scikit-optimize/
export PYTHONPATH=$PYTHONPATH:$PWD/mpi4py/
export PYTHONPATH=$PYTHONPATH:$PWD/GPTune/
export PYTHONPATH=$PYTHONPATH:$PWD/GPy/
export PATH=$PATH:$PWD/jq-1.6
export PYTHONPATH=$PYTHONPATH:$PWD/openturns/build/share/gdb/auto-load/$PWD
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$PWD/pagmo2/build/
export PYTHONWARNINGS=ignore

cd -

# name of your machine, processor model, number of compute nodes, number of cores per compute node, which are defined in .gptune/meta.json
declare -a machine_info=($(python -c "from gptune import *;
(machine, processor, nodes, cores)=list(GetMachineConfiguration());
print(machine, processor, nodes, cores)"))
machine=${machine_info[0]}
processor=${machine_info[1]}
nodes=${machine_info[2]}
cores=${machine_info[3]}


obj=r                   # name of the objective defined in the python file
niter=1                 # number of repeating each application run
bunit=8                 # mb,nb is integer multiple of bunit

database="gptune.db/PDGEQRF.json"  # the phrase PDGEQRF should match the application name defined in .gptune/meta.jason


# start the main loop
more=1
while [ $more -eq 1 ]
do

    # call GPTune and ask for the next sample point
    python ./scalapack_MLA_RCI.py -nrun $nrun -mmax $mmax -nmax $nmax -ntask $ntask -bunit \
                                  $bunit -nprocmin_pernode $nprocmin_pernode -NS1 $NS1 \
                                  -nParallel $NParallel -liar 1 -whichLiar $liarStrat
    
   


    # check through the database and return True on the first occurance of a non null character - if null is returned it means that all the
    # point have been evaluated. If all points evaluated, set the loop to end 
    idx=$( jq -r --arg v0 $obj '.func_eval | map(.evaluation_result[$v0] == null) | index(true) ' $database )
    
    

    
    if [ $idx = null ]
    then
    more=0
    fi
    og_idx=$idx
    counter=0
    # we found a point that has not been evalated, run that boy
    while [ ! $idx = null ]; 
    do 
        # echo " $idx"    # idx indexes the record that has null objective function values
        # write a large value to the database. This becomes useful in case the application crashes. 
        bigval=1e30
        jq --arg v0 $obj --argjson v1 $idx --argjson v2 $bigval '.func_eval[$v1].evaluation_result[$v0]=$v2' $database > tmp.json && mv tmp.json $database


        declare -a input_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].task_parameter' $database | jq -r '.[]'))
        declare -a tuning_para=($( jq -r --argjson v1 $idx '.func_eval[$v1].tuning_parameter' $database | jq -r '.[]'))

        
        #############################################################################
        #############################################################################
        # Modify the following according to your application !!! 


        # get the task input parameters, the parameters should follow the sequence of definition in the python file
        # rows and columns
        m=${input_para[0]}
        n=${input_para[1]}

        # get the tuning parameters, the parameters should follow the sequence of definition in the python file
        
        # row and column block size
        mb=$((${tuning_para[0]}*$bunit))
        echo "mb: $mb"
        nb=$((${tuning_para[1]}*$bunit))
        echo "nb: $nb"
        # max number of cores avaliable
        lg2npernode=${tuning_para[2]}
        echo "lg2npernode: $lg2npernode"
        
        p=${tuning_para[3]}


        # call the application
         # minimum number of MPIs per node for launching the application code
        npernode=$((2**$lg2npernode))
        echo "npernode $npernode"

        export OMP_NUM_THREADS=$(($cores / $npernode))
        nproc=$(($nodes*$npernode))

        echo "nproc: $nproc"
        echo "cores: $cores"
        echo "-c : $((128 /$nproc ))"
        q=$(($nproc / $p))

        jobid=$idx
        BINDIR=./scalapack-driver/bin/$machine/
        RUNDIR=./scalapack-driver/exp/$machine/GPTune/$jobid/
        
        # call the python wrapper to dump parameters to an input file
        python ./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $jobid -niter $niter -mode 'in' -m $m -n $n -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS -nproc $nproc -p $p -q $q -npernode $npernode

       
            
        echo "srun -N 1 -n $nproc -c $((128 /$nproc )) --cpu_bind=cores $BINDIR/pdqrdriver $RUNDIR &"
        srun -N 1 -n $nproc -c $((128 /$nproc )) --cpu_bind=cores $BINDIR/pdqrdriver $RUNDIR &

        idx=$( jq -r --arg v0 $obj '.func_eval | map(.evaluation_result[$v0] == null) | index(true) ' $database )
        counter=$((counter+1))
        #############################################################################
        #############################################################################

    
    done

    wait
    temp=`date +%s`
    i=0
  
    while [ $i -lt $counter ]; do
        

        declare -a input_para=($( jq -r --argjson v1 $og_idx '.func_eval[$v1].task_parameter' $database | jq -r '.[]'))
        declare -a tuning_para=($( jq -r --argjson v1 $og_idx '.func_eval[$v1].tuning_parameter' $database | jq -r '.[]'))

        
        #############################################################################
        #############################################################################
        # Modify the following according to your application !!! 


        # get the task input parameters, the parameters should follow the sequence of definition in the python file
        # rows and columns
        m=${input_para[0]}
        n=${input_para[1]}

        # get the tuning parameters, the parameters should follow the sequence of definition in the python file
        
        # row and column block size
        mb=$((${tuning_para[0]}*$bunit))
        nb=$((${tuning_para[1]}*$bunit))
        
        # max number of cores avaliable
        lg2npernode=${tuning_para[2]}
        p=${tuning_para[3]}


        # call the application
         # minimum number of MPIs per node for launching the application code
        npernode=$((2**$lg2npernode))
        export OMP_NUM_THREADS=$(($cores / $npernode))
        nproc=$(($nodes*$npernode))
        q=$(($nproc / $p))

            # # call the python wrapper to read results from the output file and print it out
        python ./scalapack-driver/spt/pdqrdriver_in_out.py -machine $machine -jobid $og_idx -niter $niter -mode 'out' -m $m -n $n \
                                                        -nodes $nodes -cores $cores -mb $mb -nb $nb -nthreads $OMP_NUM_THREADS \
                                                        -nproc $nproc -p $p -q $q -npernode $npernode | tee ${og_idx}_result.out
        
        result=$(grep 'PDGEQRF time:' ${og_idx}_result.out | grep -Eo '[+-]?[0-9]+([.][0-9]+)?')
        

        

        runtime=$((temp-start))
        echo "Time since start: $runtime" >> ${og_idx}_result.out
        jq --arg v0 $obj --argjson v1 $og_idx --argjson v2 $result '.func_eval[$v1].evaluation_result[$v0]=$v2' $database > tmp.json && mv tmp.json $database

        og_idx=$((og_idx+1))
        i=$((i+1))

    done 
done

end=`date +%s`

runtime=$((end-start))
echo "Total tuning time: $runtime"

