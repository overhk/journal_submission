#!/bin/bash

#SBATCH -A m2956
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -t 00:15:00
#SBATCH -J DeepHyperSeq
#SBATCH -N 16 

cd ../../
. run_env.sh
cd -

timestamp() {
  date +"%Y-%m-%d_%H-%M-%S" # current time
}

cd $GPTUNEROOT/examples/batch_scala
tp=PDGEQRF
app_json=$(echo "{\"tuning_problem_name\":\"$tp\"")
echo "$app_json$machine_json$software_json$loadable_machine_json$loadable_software_json}" | jq '.' > .gptune/meta.json

NS=100 # controls the  number of configurations to be evaluated before the BO terminates
NS1=1 # controls the number of randomly selected configurations which are evaluated before BO begins; note NS1 cannot be greater than NParallel
NParallel=16  #controls the degree of parallization
liar=0 # controls which speculation technique is used
rows=10000 # number of rows in the matrix
cols=10000 # number of cols in the matrix


rm -rf gptune.db/*.json

# a = NS
# b = minimum number of mpi count per node
# c = number of rows in matrix
# d = number of cols in matrix
# e = ntasks
# f = NS1
# g = NParallel
# h = liarStrategy
start_time=$(date +%s)
bash scalapack_MLA_RCI.sh -a $NS -b 2 -c $rows -d $cols -e 1 -f $NS1 -g $NParallel -h $liar | tee log.pdgeqrf 
end_time=$(date +%s)

elapsed_time=$(($end_time-$start_time))
echo "Total time: $elapsed_time" >> results.csv

# cleanup 
database="Liar_${liar}_NS_${NS}_NS1_${NS1}_NParallel_${NParallel}"
mkdir $database/
mkdir $database/results/
mv  *_result.out $database/results/
mv log.pdgeqrf $database/
mv predictions.csv $database/
mv results.csv $database/
mv  test.csv $database/
mv PDGEQRF.json $database/
