export PATH=$PATH:../../../env/bin/
export PYTHONPATH=$PYTHONPATH:../../../autotune/
export PYTHONPATH=$PYTHONPATH:../../../scikit-optimize/
export PYTHONPATH=$PYTHONPATH:../../../mpi4py/
export PYTHONPATH=$PYTHONPATH:../../../GPTune/
export PYTHONPATH=$PYTHONPATH:../../../GPy/
export PYTHONPATH=$PYTHONPATH:../../../pygmo2/
export PYTHONWARNINGS=ignore
